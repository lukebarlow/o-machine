O-Machine
=========

Web based model of the o-machine (http://helsonandjackets.com/index.php/omachine/omachinevideo) to develop algorithms for a projector and camera feedback loop
which produces emergent behavior

The model is visible here

https://dl.dropboxusercontent.com/u/5613860/o-machine/index.html